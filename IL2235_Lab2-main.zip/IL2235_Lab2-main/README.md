# IL2235/FIL3112: Lab 2

## Objective

This lab consist of two parts. 
In the first part, we investigate the priority inheritance mechanism that is provided by FreeRTOS.
In the second part, we experiment with the effect memory placement and other tasks executing on a different core have on task execution times.

## Preparation

Clone this repository and place it under `ES_Lab_Kit/Software/` so that it is located under `ES_Lab_Kit/Software/il2235_lab2/`.

## Lab2_A

FreeRTOS implements priority inheritance for mutexes. 
Specifically, a [simplified version](https://www.freertos.org/Documentation/02-Kernel/02-Kernel-features/02-Queues-mutexes-and-semaphores/04-Mutexes) is implemeneted.
In this lab we will study the priority inheritance protocol in FreeRTOS.

### Assignment

* How does the priority inheritance protocol in FreeRTOS differ from the priority inheritance protocol we studied in the lecture?
* Given the simplified implementation in FreeRTOS, can we still find a bound for the blocking time? If so, which one?
* Create an example application using the base project `ES_Lab_Kit/Software/il2235_lab2/Lab2_A` (configured for single-core) that demonstrates a scenario where the simplified priority inheritance protocol in FreeRTOS leads to different blocking than the normal priority inheritance protocol. Additionally draw two execution traces that visualize the expected schedules with the classic and simplified protocol.

### Help
You can create an offset for a tasks by calling `vTaskDelayUntil()` during its initialization where `lastWakeTime` is set to a value other than 0. This can be used to arrange the execution order of the initial task instances to create a specific execution sequence you want to demonstrate.

Documentation describing how to `create` a mutex is found [here](https://www.freertos.org/Documentation/02-Kernel/04-API-references/10-Semaphore-and-Mutexes/06-xSemaphoreCreateMutex).

Documentation on how to `wait` (called `take` in FreeRTOS) for a mutex is found [here](https://www.freertos.org/Documentation/02-Kernel/04-API-references/10-Semaphore-and-Mutexes/12-xSemaphoreTake), note that the function call is the same for mutex/semaphore.

Documentation on how to `signal` (called `give` in FreeRTOS) on a mutex is found [here](https://www.freertos.org/Documentation/02-Kernel/04-API-references/10-Semaphore-and-Mutexes/15-xSemaphoreGive), note that the function call is the same for mutex/semaphore.


## Lab_2B

In Lab2_B we will investigate how the memory location of data, as well as tasks executing on a different core can affect the execution time of a task. 
To demonstrate this, a project was created that already includes many parts. 
You can find it here `ES_Lab_Kit/Software/il2235_lab2/Lab2_B`.

### Benchmark Program 

The task we are investigating executes a program from the [TACLE Benchmark](https://github.com/tacle/tacle-bench), specifically [Dijkstra](https://github.com/tacle/tacle-bench/tree/master/bench/sequential/dijkstra), which has been slightly adapted from its original version for this lab.
The program is executed by a periodic task with period 100ms.
With each period, the task toggles the green LED on the board, indicating that the program is executing.

The Dijkstra benchmark consist of three main functions. 
`dijkstra_init()`, `dijkstra_main()` and `dijkstra_return()`.
We are interested in the execution time of `dijkstra_main()`.

`dijkstra_init()` is called for every task instance and initializes all data structures needed.

`dijkstra_main()` computes the shortest path between nodes in a graph. We will vary the memory location of this input data. 

`dijkstra_return()` is used to check if the computed result is correct. In case the result is incorrect, the red LED is turned on.

For each task instance, the measured execution time of `dijkstra_main()` is printed to the terminal. 

### Memory Locations

The program allows to move the input data for the Dijkstra program to different memory locations on the platform. 
The configuration is performed in line 98 of `main.c` (see the code-comment above the struct for possible values).

Three different options are supported:
* **SRAM**: On-chip SRAM banks
* **PSRAM cached**: External PSRAM chip accessed over XIP-cache 
* **PSRAM non-cached**: External PSRAM chip without access over XIP-cache

Study the [RP2350 Datasheet ](https://pip-assets.raspberrypi.com/categories/1214-rp2350/documents/RP-008373-DS-2-rp2350-datasheet.pdf)
and how the different memories are connected to the CPU.

### Attacker Task

All memories used are shared between the two cores of the RP2350. 
The program also contains the possibility to enable an "attacker task".
The attacker task creates a large number of memory requests with the intention to interfere with the operation of the Dijkstra task on the other core. 

Enable the attacker task by enabling `#define USE_ATTACKER_TASK` on line 111 in `main.c`.

You can then configure which type of requests you like to create: write requests, read requests, or a mix of bith (enable one of the options on line 116 to 118 in `main.c`).

### Assignment

* Familiarize yourself with the provided program. 
* Measure the execution time of `dijkstra_main()` for the different memory locations (collect at least 100 measurements for each setting), alone and with different configurations of the attacker task and record the minimum, average and maximum values in a table. If you have the attacker task active, only investigate memory settings `PSRAM_CACHED` and `PSRAM_UNCACHED`. In total you will have 9 different setting (2 possible memory locations with: no attacker task, or attacker with read, write, or mixed requests, respectively. Plus the configuration without attacker task and on-chip SRAM memory). 
* Use the setting with Dijkstra input in `PSRAM_CACHED` and the attacker task creating read and write requests. For this setting we want to investigate where memory requests of different cores interfere with each other. The RP2350 has a number of performance counters we can use for this purpose. Specifically, we can monitor the bus interconnect (see 12.15.4.2. Performance counters in the datasheet) and the XIP cache (see 4.4.4. Performance counters in the datasheet). Configure the performance counters and read the number of contested accesses on the bus, and cache misses (cache accesses - cache hits) for a task instance. What are the maximum values you observed?

## Examination
Demonstrate the programs that you have developed for the laboratory staff during your laboratory session. Be prepared to explain your program in detail and answer the questions of each lab task.

Submit your programs (i.e. the folder IL2235_Lab2) as zip-file in the assignment Lab2 in Canvas.