#include <stdio.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "bsp.h"

/* ========= 全局互斥锁 ========= */
SemaphoreHandle_t mtxA;   /* 资源 A */
SemaphoreHandle_t mtxB;   /* 资源 B */

/* ========= 任务句柄（可选，用于调试） ========= */
TaskHandle_t    hTaskL = NULL;
TaskHandle_t    hTaskM = NULL;
TaskHandle_t    hTaskH = NULL;

/* ========= 工具函数 ========= */

/* 打印当前任务名、优先级和一条消息 */
static void log_msg(const char *tag, const char *msg)
{
    TickType_t now = xTaskGetTickCount();
    UBaseType_t prio = uxTaskPriorityGet(NULL);
    printf("[%6u][%s p=%lu] %s\n",
           (unsigned)now, tag, (unsigned)prio, msg);
}

/* 忙等一段时间（真正在吃 CPU，不调用 delay） */
static void busy_ms(uint32_t ms)
{
    TickType_t start   = xTaskGetTickCount();
    TickType_t ticks   = pdMS_TO_TICKS(ms);

    while ((xTaskGetTickCount() - start) < ticks) {
        __asm volatile("nop");
    }
}

/* ========= 任务声明 ========= */
static void low_task(void *args);    /* L：低优先级，持有 A 和 B */
static void mid_task(void *args);    /* M：中优先级，只忙 CPU */
static void high_task(void *args);   /* H：高优先级，只需要 A */

/*************************************************************/
/**
 * @brief Main function.
 */
int main(void)
{
    BSP_Init();             /* 初始化 lab-kit (串口/LED 等). */

    /* 创建两个 mutex（带 FreeRTOS 简化 PIP） */
    mtxA = xSemaphoreCreateMutex();
    mtxB = xSemaphoreCreateMutex();

    /* 创建三个任务：优先级 L(1) < M(2) < H(3) */
    xTaskCreate(low_task,  "Low",  512, NULL, 1, &hTaskL);
    xTaskCreate(mid_task,  "Mid",  512, NULL, 2, &hTaskM);
    xTaskCreate(high_task, "High", 512, NULL, 3, &hTaskH);

    vTaskStartScheduler();  /* Start the scheduler. */

    /* 不应运行到这里 */
    while (true) {
        sleep_ms(1000);
    }
}

/*-----------------------------------------------------------*/
/**
 * @brief L：低优先级任务
 *
 * 行为：
 * 1) 先拿 mtxA，做一点工作；
 * 2) 再拿 mtxB，此时同时持有 A 和 B；
 * 3) 释放 A，但仍然持有 B —— 这里按“传统 PIP”它应该降回低优先级，
 *    但 FreeRTOS 简化 PIP 会让它维持继承的高优先级；
 * 4) 在只持有 B 的情况下继续长时间 busy（会以高优先级运行）。
 */
static void low_task(void *args)
{
    (void)args;

    vTaskDelay(pdMS_TO_TICKS(5));  /* 稍等一下，让系统稳定 */

    log_msg("L", "trying to take mtxA");
    xSemaphoreTake(mtxA, portMAX_DELAY);
    log_msg("L", "got mtxA");

    /* 在 A 的临界区里做一点短工作 */
    busy_ms(20);

    log_msg("L", "trying to take mtxB");
    xSemaphoreTake(mtxB, portMAX_DELAY);
    log_msg("L", "got mtxB (holding A & B)");

    /* 再做一点工作，确保这时 H 已经在系统里 */
    busy_ms(10);

    /* ====== 关键点 1：释放 A，但仍持有 B ====== */
    log_msg("L", "releasing mtxA (still holding mtxB)");
    xSemaphoreGive(mtxA);

    /* 按课本 PIP：这里 L 不再阻塞 H，应该立刻降回 base priority=1。
       但 FreeRTOS 简化 PIP：L 仍持有 mtxB -> 继续保持继承来的最高优先级。 */

    /* ====== 关键点 2：只拿着 B 时的“额外高优先级执行” ====== */
    log_msg("L", "extra work while only holding mtxB");
    busy_ms(80);  /* 这段会以高优先级执行，把中优先级 M 压住 */

    log_msg("L", "releasing mtxB");
    xSemaphoreGive(mtxB);

    log_msg("L", "done, sleeping forever");
    for (;;)
        vTaskDelay(portMAX_DELAY);
}

/*-----------------------------------------------------------*/
/**
 * @brief M：中优先级任务
 *
 * 不使用 mutex，只想占用 CPU 一段时间。
 * 在传统 PIP 下，H 拿到 mtxA 后，它应该比 L 先得到 CPU；
 * 在 FreeRTOS 简化 PIP 下，由于 L 仍保持高优先级，M 会被推迟。
 */
static void mid_task(void *args)
{
    (void)args;

    vTaskDelay(pdMS_TO_TICKS(40));  /* 等链条搭好，再醒来 */

    log_msg("M", "woken up, start busy work");
    busy_ms(60);
    log_msg("M", "finished busy work");

    for (;;)
        vTaskDelay(portMAX_DELAY);
}

/*-----------------------------------------------------------*/
/**
 * @brief H：高优先级任务
 *
 * 只需要 mtxA。被 L 挡在 A 前面时会触发优先级继承。
 * 我们测量 H 被阻塞的时间，并观察 M 被延迟的程度。
 */
static void high_task(void *args)
{
    (void)args;

    vTaskDelay(pdMS_TO_TICKS(15));  /* 等 L 拿到 A（甚至 B）之后再来 */

    log_msg("H", "trying to take mtxA");

    TickType_t t0 = xTaskGetTickCount();
    xSemaphoreTake(mtxA, portMAX_DELAY);   /* 会被 L 阻塞一段时间 */
    TickType_t t1 = xTaskGetTickCount();

    char buf[96];
    snprintf(buf, sizeof(buf),
             "got mtxA, blocking time = %u ticks (~%u ms)",
             (unsigned)(t1 - t0),
             (unsigned)((t1 - t0) * portTICK_PERIOD_MS));
    log_msg("H", buf);

    /* 在 A 的临界区做一点事情 */
    busy_ms(20);
    xSemaphoreGive(mtxA);
    log_msg("H", "released mtxA, done");

    for (;;)
        vTaskDelay(portMAX_DELAY);
}
